% Set-up

Bm=35; %Set number of simulated data set in SIMEX
K=2; %Set K for calibration deconvolution method

mePv = [1/6, 0, 3/7, 3/4]; %varU/varS ratios

%Data preparation
load('HanebookData')
Y = Data(:,1);
Age = Data(:,2);
PIR = log(Data(:,3));
BMI = Data(:,4);
ALC = Data(:,5);
FH = Data(:,6);
AM = Data(:,7)-1;
PM = Data(:,8)-1;
Race = Data(:,9)-1;
%Cal = Data(:,11);
X = [Age,PIR,BMI,ALC,FH,AM,PM,Race];
Si = log(5+Data(:,10)*100);

errortype='norm'; %Set errortype
varS = var(Si);

%Set plot grid
q1 = quantile(Si,0.1);
q2 = quantile(Si,0.9);
t0 = q1:(q2-q1)/49:q2;

ED = zeros(4,50); %set the vector to save the estimated curve results


for r = 2:4
    meP = mePv(r);
varU = meP*varS; %variance of measurement error
b = sqrt(varU);

if meP == 0 
%% Naive Estimator
    [bwD,K1,K2,~] = CV_Naive(Si,Y,X);
    weightN = get_weight_Naive(X,Si,K1,K2);
    weightN=diag(weightN);
    ED(r,:)= CaliEst_Naive(bwD,t0,Si,Y,weightN);
else
%% Deconvolution-Calibrationn Estimator
    hPI = PI_deconvUknownth4(Si,errortype,varU,b);
    weight = get_weightCon(t0,X,X,Si,errortype,hPI,K,b);
    [bwD,~,~,~,ridgeD] = SIMEXRegbw(Si,Y,X,errortype,b,Bm,K);
    [ED(r,:),~] = weightNWDecUknown(t0,Si,Y,weight,errortype,b,bwD,ridgeD);

end
%% Estimate Confidence intervals using undersmoothing for meP = 1/6

meP = mePv(1);
if meP <= 0.33
q1 = quantile(Si,0.1);
q2 = quantile(Si,0.9);
t00 = q1:(q2-q1)/49:q2;
elseif meP <= 0.67
q1 = quantile(Si,0.15);
q2 = quantile(Si,0.85);
t00 = q1:(q2-q1)/49:q2;
else
q1 = quantile(Si,0.2);
q2 = quantile(Si,0.8);
t00 = q1:(q2-q1)/49:q2;
end

varU = meP*varS; %variance of measurement error
b = sqrt(varU);
hPI = PI_deconvUknownth4(Si,errortype,varU,b);
weight = get_weightCon(t00,X,X,Si,errortype,hPI,K,b);
[bwD,bwStar,bw1,bw2,ridgeD] = SIMEXRegbw(Si,Y,X,errortype,b,Bm,K);
[ED(1,:),~] = weightNWDecUknown(t00,Si,Y,weight,errortype,b,bwD,ridgeD);
%Sub-routines: (1) CV_fdecCond.m
%              (2) hSIMEXUknown.m
%              (3) underSmooth.m
N = length(Y);

h21= CV_fdecCond(N,t00,Si,[X,Y],errortype,b,hPI);
h22 = CV_fdecCond(N,t00,Si,X,errortype,b,hPI);

d = size(X,2);
parfor dim = 1:d
    dim
[bwXT(dim),rhoXT(dim),~,~]=hSIMEXUknown(Si,X(:,dim),errortype,b,20);
end
[bwYT,rhoYT,~,~]=hSIMEXUknown(Si,Y,errortype,b,20);

d = size(X,2);
if d>1
    parfor dim = 1:d
        EXTt(dim,:) =  NWDecUknown(Si,Si,X(:,dim),errortype,b,bwXT(dim),rhoXT(dim));
    end
else
EXTt =  NWDecUknown(Si,Si,X,errortype,b,bwXT,rhoXT);
end
EYTt =  NWDecUknown(Si,Si,Y,errortype,b,bwYT,rhoYT);
Xtilde = X - EXTt';
Ytilde = Y - EYTt';
XYtilde = Xtilde'*Ytilde;
betahat = (Xtilde'*Xtilde)\XYtilde;
[bwYtX,rhoYtX,~,~]=hSIMEXUknown(Si,Y-X*betahat,errortype,b,20);
ghatt = NWDecUknown(t00,Si,Y-X*betahat,errortype,b,bwYtX,rhoYtX);
EYtX = X*betahat + ghatt;

[bw_us,biashat,sdIF,muhat] = underSmooth(N,t00,X,Si,Y,hPI,K,...
    bwD,ridgeD,EYtX,errortype,varU,b,h21,h22,0);


CIlbest = muhat- 1.96*sdIF;
CIubest = muhat+1.96*sdIF;
end

%% Plot
figure
xconf = [t00 t00(end:-1:1)] ;
yconf = [CIubest CIlbest(end:-1:1)];
p = fill(xconf,yconf,[0.85,0.85,0.85],'LineStyle','none');
hold on
plot(t0,ED(1,:),'--',t0,ED(2,:),':',t0,ED(3,:),'-.',t0,ED(4,:),'LineWidth',1,'Color','k');
xlabel('$\ln$(5+Saturated Fat)','FontSize',20,'Interpreter','latex')
ylabel('E\{Y(t)\}','FontSize',20)


filename = sprintf('NHANES_D_me_T95_Cal.mat');
save(filename)