The main code for running the real data analysis is RealDataAnalysis.m
