%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Wei Huang and Zheng Zhang (2021).
%  Wei Huang and Zheng Zhang (2022).
% Nonparametric Estimation of the Continuous Treatment
% Effect with Measurement Error
%
% Main Matlab codes for Monte Carlo simulations on Estimation of ADRF
% using Naive estimator.
% *****************************************************
% Subroutines directly used in this main code:
%    (0) DGP1_ME.m; DGP2_ME.m; DGP3_ME.m; DGP4_ME.m: Data generation
%    processes
%    (1) Opt_Naive.m %theoretical optimal parameters
%    (2) CV_NaiveFull.m %10-fold cross-validation for parameters
%    (3) get_weight_Naive.m %naive way to estimate pi
%    (4) CaliEst_Naive.m %naive way to estimate mu
% *****************************************************
%
% Written by:
%    Wei Huang
%    Lecturer
%    School of Mathematics and Statistics, The University of Melbourne
%
% Last updated:
%    19 April, 2022.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function MC_simNaive(DGP, N, error)
%DGP: data generating process: 1 2 3 or 4
%N: sample size: 250 or 500
%error: error type, 1: 'Laplace' or 2: 'normal'.

tic;                                           % start timing
start_date = now;                              % start date
disp(['Job started: ', datestr(start_date)]);  % display start date

%% Step 1: Set-up
%N=250;
J=200;

if error == 1
    errortype = 'Lap'; %Type of the error distribution, 2 choices: 'Lap' or 'norm'
elseif error == 2
    errortype = 'norm';
end
%DGP = 1;

warning('off','all')

if DGP == 1
   [~,~, ~, ~,~, b,t0,mu,vUXr] = DGP1_ME(10000,1,errortype);
elseif DGP == 2
   [~,~, ~, ~,~, b,t0,mu,vUXr] = DGP2_ME(10000,1,errortype);
elseif DGP == 3
   [~,~, ~, ~,~, b,t0,mu,vUXr] = DGP3_ME(10000,1,errortype);
elseif DGP == 4
   [~,~, ~, ~,~, b,t0,mu,vUXr] = DGP4_ME(10000,1,errortype);
end

if strcmp(errortype,'Lap')==1
	varU = 2*b^2;
elseif strcmp(errortype,'norm')==1
	varU = b^2;
end
               
parfor j =1:J
    disp(j);
    
        if DGP == 1
            [Y,X, ~, Si,~, ~,~,~,~] = DGP1_ME(N,j,errortype);
        elseif DGP == 2
            [Y,X, ~, Si,~, ~,~,~,~] = DGP2_ME(N,j,errortype);
        elseif DGP == 3
            [Y,X, ~, Si,~, ~,~,~,~] = DGP3_ME(N,j,errortype);
        elseif DGP == 4
            [Y,X, ~, Si,~, ~,~,~,~] = DGP4_ME(N,j,errortype);
        end
    YDG(:,j) = Y;
    XDG(:,j) = X;
    SDG(:,j) = Si;

    %Naive estimator using theoretical optimal smoothing parameters (NV)
    [bwNOpt(j),idxNOpt(j),K1NOpt(j),K2NOpt(j),ISENOpt(j)] = Opt_Naive(t0,mu,Si,Y,X);
    weight = get_weight_Naive(Si,X,X,Si,K1NOpt(j),K2NOpt(j));
    weight=diag(weight);
    [NV(j,:),~]= CaliEst_Naive(bwNOpt(j),t0,Si,Y,weight);
    
    %CV K1 K2 bw for Naive
    [bwFNCV(j),K1NCV(j),K2NCV(j),~] = CV_NaiveFull(Si,Y,X);
    weight = get_weight_Naive(Si,X,X,Si,K1NCV(j),K2NCV(j));
    weight=diag(weight);
    ENFCV(j,:)= CaliEst_Naive(bwFNCV(j),t0,Si,Y,weight);
    ISENFCV(j) = mean((ENFCV(j,:)-mu).^2);
    
  
end

filename=sprintf('DGP%d-%s-vUXr-%.2f-N%d-Naive.mat',DGP,errortype,vUXr,N);
save(filename)

%% Step 3: Report computational time 
time = toc;        % finish timing
end_date = now;    % end date
disp('*****************************************');
disp(['Job started: ', datestr(start_date)]);
disp(['Job finished: ', datestr(end_date)]);
disp(['Computational time: ', num2str(time), ' seconds.']);
disp(['Computational time: ', num2str(time / 60), ' minutes.']);
disp(['Computational time: ', num2str(time / 3600), ' hours.']);
disp('*****************************************');
disp(' ');

end
