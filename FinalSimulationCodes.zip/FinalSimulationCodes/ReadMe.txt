The main code for running the simulations using our proposed method is MC_simSIMEXLC.m
The main code for the naive method is MC_simNaive.m

The confidence interval code is in ConfidencebandUS.m