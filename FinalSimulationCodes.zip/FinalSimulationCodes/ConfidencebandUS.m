function ConfidencebandUS(DGP, N, error)

%Estimate Confidence intervals using undersmoothing

%Sub-routines: (1) CV_fdecCond.m
%              (2) hSIMEXUknown.m
%              (3) underSmooth.m
%              (4) NWDecUknown
%              (5) EYTXLiang


if error == 1
    errortype = 'Lap';
elseif error == 2 
    errortype = 'norm'; %Type of the error distribution, 2 choices: 'Lap' or 'norm'
end

if DGP == 1
   [~,~, ~, ~,~, ~,~,~,vUXr] = DGP1_ME(10000,1,errortype);
elseif DGP == 2
   [~,~, ~, ~,~, ~,~,~,vUXr] = DGP2_ME(10000,1,errortype);
elseif DGP == 3
   [~,~, ~, ~,~, ~,~,~,vUXr] = DGP3_ME(10000,1,errortype);
elseif DGP == 4
   [~,~, ~, ~,~, ~,~,~,vUXr] = DGP4_ME(10000,1,errortype);
end
     
filename=sprintf('DGP%d-%s-vUXr-%.2f-N%d-Opt-%s.mat',DGP,errortype,vUXr,N,date);
load(filename, "XDG","SDG","YDG","J","t0","b","hPI","K","bwSIMEX","ridgeSIMEX","varU","mu")

j = 1;
X = XDG(:,j);
Si = SDG(:,j);
Y = YDG(:,j);
h21= CV_fdecCond(N,t0,Si,[X,Y],errortype,b,hPI(j));
h22 = CV_fdecCond(N,t0,Si,X,errortype,b,hPI(j));
[bwXT,rhoXT,~,~]=hSIMEXUknown(Si,X,errortype,b,20);
[bwYT,rhoYT,~,~]=hSIMEXUknown(Si,Y,errortype,b,20);

EXTt =  NWDecUknown(Si,Si,X,errortype,b,bwXT,rhoXT);
EYTt =  NWDecUknown(Si,Si,Y,errortype,b,bwYT,rhoYT);
Xtilde = X - EXTt';
Ytilde = Y - EYTt';
XYtilde = Xtilde'*Ytilde;
betahat = (Xtilde'*Xtilde)\XYtilde;

[bwYtX,rhoYtX,~,~]=hSIMEXUknown(Si,Y-X*betahat,errortype,b,20);

parfor j = 1:J
    disp(j);
    X = XDG(:,j);
    Si = SDG(:,j);
    Y = YDG(:,j);
    
    EYtX = EYTXLiang(t0,X,Si,Y,bwYtX,rhoYtX,bwXT,rhoXT,bwYT,rhoYT,errortype,b);
    
    [bw_us(j),h_us(j),biashat(j,:),sdIF(j,:),muhat(j,:)] = underSmooth(N,t0,X,Si,Y,hPI(j),K(j),...
        bwSIMEX(j),ridgeSIMEX(j),EYtX,errortype,varU,b,h21,h22,0);
end

CIlbest = muhat - 1.96*sdIF;
CIubest = muhat+1.96*sdIF;

inCIest = mu<=CIubest & mu>=CIlbest;

CPest = mean(inCIest,1);

 filename=sprintf('DGP%d-%s-vUXr-%.2f-N%d-CIUSh-%s.mat',DGP,errortype,vUXr,N,date);
 save(filename)
end