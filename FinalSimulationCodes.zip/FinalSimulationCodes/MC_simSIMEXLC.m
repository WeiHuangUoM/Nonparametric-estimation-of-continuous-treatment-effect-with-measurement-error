%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Wei Huang and Zheng Zhang (2022).
% Nonparametric Estimation of the Continuous Treatment
% Effect with Measurement Error
%
% Main Matlab codes for Monte Carlo simulations on Estimation of ADRF
%
% *****************************************************
% Subroutines directly used in this main code:
%    (0) DGP1_ME.m; DGP2_ME.m; DGP3_ME.m; DGP4_ME.m: Data generation
%    processes
%    (1) Opt_Cali.m %theoretical optimal parameters
%    (2) Opt_Calibw.m %h0=hPI, K: by GCV and h: theoretical optimal
%    (3) SIMEXRegbw.m %our SIMEX method to choose h
%    (4) get_weightCon.m %estimate pi
%    (5) weightNWDecUknown.m %estimate mu
% *****************************************************
%
% Written by:
%    Wei Huang
%    Lecturer
%    School of Mathematics and Statistics, The University of Melbourne
%
% Last updated:
%    19 April, 2022.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function MC_simSIMEXLC(DGP, N, error)

%% Step 1: Set-up
%N=500; %sample size
J=20; %Number of Monte-Carlo samples
Bm=35; %Number of bootstrap in SIMEX method of selecting bandwidth

if error == 1
    errortype = 'Lap';
elseif error == 2 
    errortype = 'norm'; %Type of the error distribution, 2 choices: 'Lap' or 'norm'
end
        
%DGP = 1;  %Data generation process: 1, 2, 3, 4

warning('off','all')

if DGP == 1
   [~,~, ~, ~,~, b,t0,mu,vUXr] = DGP1_ME(10000,1,errortype);
elseif DGP == 2
   [~,~, ~, ~,~, b,t0,mu,vUXr] = DGP2_ME(10000,1,errortype);
elseif DGP == 3
   [~,~, ~, ~,~, b,t0,mu,vUXr] = DGP3_ME(10000,1,errortype);
elseif DGP == 4
   [~,~, ~, ~,~, b,t0,mu,vUXr] = DGP4_ME(10000,1,errortype);
end

if strcmp(errortype,'Lap')==1
	varU = 2*b^2;
elseif strcmp(errortype,'norm')==1
	varU = b^2;
end
               
parfor j =1:J
    disp(j);
    %% Generate data
        if DGP == 1
            [Y,X, ~, Si,~, ~,~,~,~] = DGP1_ME(N,j,errortype);
        elseif DGP == 2
            [Y,X, ~, Si,~, ~,~,~,~] = DGP2_ME(N,j,errortype);
        elseif DGP == 3
            [Y,X, ~, Si,~, ~,~,~,~] = DGP3_ME(N,j,errortype);
        elseif DGP == 4
            [Y,X, ~, Si,~, ~,~,~,~] = DGP4_ME(N,j,errortype);
        end
    YDG(:,j) = Y;
    XDG(:,j) = X;
    SDG(:,j) = Si;
    
    %Y = YDG(:,j);
    %X = XDG(:,j);
    %Si = SDG(:,j);

    %Our method using theoretical optimal smoothing parameters (CM)
    [KOpt(j),bwOpt(j),hwOpt(j),ridgeOpt(j),idrOpt(j),idxOpt(j),ISEOpt(j)]...
        = Opt_Cali(t0,mu,Si,Y,X,errortype,b);
    weight = get_weightCon(t0,X,X,Si,errortype,hwOpt(j),KOpt(j),b);
    [EDOpt(j,:),~,~] = weightNWDecUknown(t0,Si,Y,weight,errortype,b,...
        bwOpt(j),ridgeOpt(j));
    
    %Choose h0 and K
    hPI(j) = PI_deconvUknownth4(Si,errortype,varU,b);
    Kg = 2:4;
    lhK = length(Kg);
    eX = exp(X);
    meX = mean(eX);
    GCV = zeros(3,1);
    for i = 1:lhK
        try
        weight = get_weightCon(t0,X,X,Si,errortype,hPI(j),Kg(i),b);
        %weight = zeros(N,length(t0));
        EXT = weightNWDecUknown(t0,Si,eX,weight,errortype,b,hPI(j),0.01);
        GCV(i) = sum((EXT - meX).^2)/(1-N^(-1)*Kg(i))^2;
        catch ME
        disp(ME.message)
        GCV(i) = Inf;
        end
    end
    K(j) = min(Kg(GCV==min(GCV)));
    weight = get_weightCon(t0,X,X,Si,errortype,hPI(j),K(j),b);
    
    %Our method using h0=hPI, K selected by method in section 5.2 and
    %theretical optimal h (CM_tilde)
    [bwOpttilde(j),~,ridgeOpttilde(j),~,~,ISEOptbw(j)]...
        = Opt_Calibw(t0,mu,Si,Y,X,errortype,b,K(j));
    [EDOptbw(j,:),~,~] = weightNWDecUknown(t0,Si,Y,weight,errortype,b,...
       bwOpttilde(j),ridgeOpttilde(j));
   
    
    %Our method using our data-driven smoothing parameters (CM_hat)
    [bwSIMEX(j),bwStar(j),bw1(:,j),bw2(:,j),ridgeSIMEX(j)] = SIMEXRegbw(Si,Y,X,K(j),errortype,b,Bm);
    [ENSIMEX(j,:),~,~] = weightNWDecUknown(t0,Si,Y,weight,errortype,b,bwSIMEX(j),ridgeSIMEX(j));
    ISESIMEX(j) = mean((ENSIMEX(j,:)-mu).^2);
end



filename=sprintf('DGP%d-%s-vUXr-%.2f-N%d-Opt-%s.mat',DGP,errortype,vUXr,N,date);
save(filename)

end
