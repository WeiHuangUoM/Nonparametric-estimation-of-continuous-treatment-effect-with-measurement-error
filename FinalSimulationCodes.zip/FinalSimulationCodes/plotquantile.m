function [q1E,mE,q2E]=plotquantile(ISE,Etyes)

nJ = size(Etyes,1)*size(Etyes,2);
J = length(ISE);
Etyes = reshape(Etyes,J,nJ/J);

[~,idx] = sort(ISE);
q1 = floor(0.25*J);
m = floor(0.5*J);
q2= floor(0.75*J);

q1E = Etyes(idx(q1),:);
mE = Etyes(idx(m),:);
q2E = Etyes(idx(q2),:);

end

%%
% Plot the simulated results
% Example: plot CM_hat: [q1E,mE,q2E]=plotquantile(ISESIMEX,ENSIMEX)
%          figure; plot(t0, q1E, t0, mE, t0, q2E)